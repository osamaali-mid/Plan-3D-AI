import os
import shutil

# Paths
source_folder = "./images"  # Replace with the path to your main folder containing subfolders
destination_folder = "./gens"  # Replace with the path to your destination folder

# Ensure the destination folder exists
os.makedirs(destination_folder, exist_ok=True)

# Iterate through the subfolders
for root, dirs, files in os.walk(source_folder):
    # Check if the folder contains both test.json and test.png
    json_files = [f for f in files if f.endswith(".json")]
    png_files = [f for f in files if f.endswith(".png")]

    if len(json_files) > 0 and len(png_files) > 0:
        # Assume the folder name is the desired new file name
        folder_name = os.path.basename(root)
        print(f"Processing folder: {folder_name}")

        # Process .json file
        for json_file in json_files:
            source_json_file = os.path.join(root, json_file)
            destination_json_file = os.path.join(destination_folder, f"{folder_name}.json")
            shutil.copy2(source_json_file, destination_json_file)
            print(f"Copied and renamed {source_json_file} to {destination_json_file}")

        # Process .png file
        for png_file in png_files:
            source_png_file = os.path.join(root, png_file)
            destination_png_file = os.path.join(destination_folder, f"{folder_name}.png")
            shutil.copy2(source_png_file, destination_png_file)
            print(f"Copied and renamed {source_png_file} to {destination_png_file}")

print("All files have been processed!")
